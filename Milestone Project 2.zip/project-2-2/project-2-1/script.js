const API = "https://countries.dev/countries?fields=name,alpha2Code,alpha3Code,capital,region,subregion,population,flag,flags,currencies,languages,borders";

const container = document.getElementById("countryContainer");
const search = document.getElementById("searchInput");
const region = document.getElementById("regionFilter");
const status = document.getElementById("status");

const homePage = document.getElementById("homePage");
const detailPage = document.getElementById("detailPage");
const details = document.getElementById("countryDetails");

const favoriteBtn = document.getElementById("favoriteBtn");

let countries = [];
let favorites = JSON.parse(localStorage.getItem("favorites")) || [];
let selectedCountry = null;


async function getCountries() {
  try {
    status.textContent = "Loading countries...";

    const res = await fetch(API);

    if (!res.ok) throw new Error("API request failed");

    countries = await res.json();

    countries.sort((a, b) => a.name.localeCompare(b.name));

    showCountries(countries);

    status.textContent = `${countries.length} countries found`;

  } catch (error) {
    console.error(error);
    status.textContent = "Unable to load countries. Please check your internet.";
  }
}

function showCountries(data) {

  container.innerHTML = "";

  if (data.length === 0) {
    container.innerHTML = `
      <p class="text-gray-500 col-span-full text-center py-10">
        No countries found!
      </p>
    `;
    return;
  }

  data.forEach(country => {

    const card = document.createElement("div");

    card.className =
      "bg-white dark:bg-gray-900 rounded-xl shadow-sm overflow-hidden cursor-pointer border border-gray-100 dark:border-gray-800 transition-all duration-300 ease-[ease] hover:-translate-y-1.5";

    card.innerHTML = `
      <img
        src="${country.flags?.svg || country.flags?.png || ""}"
        class="w-full h-44 object-cover"
        alt="${country.name} flag"
      >

      <div class="p-5">

        <h2 class="text-xl font-bold mb-4">
          ${country.name}
        </h2>

        <div class="space-y-2 text-sm text-gray-600 dark:text-gray-400">

          <p>
            <b class="text-gray-800 dark:text-white">Population:</b>
            ${Number(country.population || 0).toLocaleString()}
          </p>

          <p>
            <b class="text-gray-800 dark:text-white">Region:</b>
            ${country.region || "N/A"}
          </p>

          <p>
            <b class="text-gray-800 dark:text-white">Capital:</b>
            ${country.capital || "N/A"}
          </p>

        </div>

        <p class="text-blue-600 text-sm font-semibold mt-5">
          View Details →
        </p>

      </div>
    `;

    card.addEventListener("click", () => showDetails(country));

    container.appendChild(card);

  });
}

function filterCountries() {

  const text = search.value.toLowerCase().trim();
  const selectedRegion = region.value;

  const filtered = countries.filter(country =>
    country.name.toLowerCase().includes(text) &&
    (!selectedRegion || country.region === selectedRegion)
  );

  showCountries(filtered);

  status.textContent = `${filtered.length} countries found`;
}

search.addEventListener("input", filterCountries);
region.addEventListener("change", filterCountries);

function showDetails(country) {

  selectedCountry = country;

  homePage.classList.add("hidden");
  detailPage.classList.remove("hidden");

  const isFavorite = favorites.some(
    item => item.name === country.name
  );

  favoriteBtn.textContent = isFavorite
    ? "❤️ Remove Favorite"
    : "❤️ Add Favorite";

  const currency = (country.currencies || [])
    .map(c => c.name).join(", ") || "N/A";

  const languages = (country.languages || [])
    .map(l => l.name).join(", ") || "N/A";

  const borders = (country.borders || []).join(", ") || "None";

  details.innerHTML = `

    <img
      src="${country.flags?.svg || country.flags?.png || ""}"
      class="w-full rounded-xl shadow-sm"
      alt="${country.name} flag"
    >

    <div>

      <h2 class="text-3xl font-bold mb-8">
        ${country.name}
      </h2>

      <div class="grid sm:grid-cols-2 gap-5 text-sm">

        <p><b>Population:</b> ${Number(country.population || 0).toLocaleString()}</p>

        <p><b>Region:</b> ${country.region || "N/A"}</p>

        <p><b>Sub Region:</b> ${country.subregion || "N/A"}</p>

        <p><b>Capital:</b> ${country.capital || "N/A"}</p>

        <p><b>Currency:</b> ${currency}</p>

        <p><b>Languages:</b> ${languages}</p>

        <p class="sm:col-span-2">
          <b>Border Countries:</b> ${borders}
        </p>

      </div>

    </div>
  `;
}

favoriteBtn.addEventListener("click", () => {

  if (!selectedCountry) return;

  const isFavorite = favorites.some(
    item => item.name === selectedCountry.name
  );

  if (isFavorite) {

    favorites = favorites.filter(
      item => item.name !== selectedCountry.name
    );

    favoriteBtn.textContent = "❤️ Add Favorite";

  } else {

    favorites.push(selectedCountry);

    favoriteBtn.textContent = "❤️ Remove Favorite";

  }

  localStorage.setItem("favorites", JSON.stringify(favorites));

});

document.getElementById("backBtn").addEventListener("click", () => {

  detailPage.classList.add("hidden");
  homePage.classList.remove("hidden");

});

document.getElementById("themeBtn").addEventListener("click", () => {

  document.documentElement.classList.toggle("dark");

  const dark = document.documentElement.classList.contains("dark");

  document.getElementById("themeBtn").textContent =
    dark ? "☀️ Light Mode" : "🌙 Dark Mode";

});

getCountries();